﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;
using WpfApp10.Pages;
using WpfApp10.QuestPages;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для LoginAdmn.xaml
    /// </summary>
    public partial class LoginAdmn : Page
    {
        public LoginAdmn()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
           

            try
            {
                var userObj = DbConnect.entObj.User.FirstOrDefault(x => x.Login == TxbLogin.Text && x.Password == PsbPassword.Password);

                if (userObj == null)
                {
                    MessageBox.Show("Такой пользователь не найден!",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information);
                    FrameApp.frmObj.Navigate(new Registration());
                }
                else
                {
                    switch (userObj.IdRole)
                    {
                        case 1:
                            MessageBox.Show("Здравствуйте, посетитель " + userObj.Login + "!",
                                            "Уведомление",
                                            MessageBoxButton.OK);
                            FrameApp.frmObj.Navigate(new PageClient());
                            break;
                        
                        case 2:
                            MessageBox.Show("Здравствуйте, администратор " + userObj.Login + "!",
                                            "Уведомление",
                                            MessageBoxButton.OK,
                                            MessageBoxImage.Information);
                            FrameApp.frmObj.Navigate(new PageAdmin());
                            break;
                    }
                    FrameApp.BtnCheck1.Visibility = Visibility.Visible;
                    FrameApp.BtnCheck2.Visibility = Visibility.Visible;
                    FrameApp.BtnCheck3.Visibility = Visibility.Visible;
                    FrameApp.BtnCheck4.Visibility = Visibility.Visible;
                    FrameApp.BtnCheck5.Visibility = Visibility.Visible;
                    FrameApp.BtnLogin.Visibility = Visibility.Hidden;
                    FrameApp.BtnRegistr.Visibility = Visibility.Hidden;

                    
                }
            }   
            catch (Exception ex)
            {
                MessageBox.Show("Критический сбой работы приложения:" + ex.Message.ToString(),
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                
            }

            
        }
        

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new Registration());
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
