﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для PageAdmin.xaml
    /// </summary>
    public partial class PageAdmin : Page
    {
        public PageAdmin()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void BtnAddDish_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddDish());
        }

        private void BtnAddFood_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddProduct());
        }

        private void BtnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddRecipe());
        }

        private void BtnProductToDish_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new ProductToDish());
        }

        private void BtnFoodList_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageFoodList());
        }

        
        private void BtnDishList_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageDishList());
        }

        private void BtnRecipeList_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageRecipeList());
        }
    }
}
