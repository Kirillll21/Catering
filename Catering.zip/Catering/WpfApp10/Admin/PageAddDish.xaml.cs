﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для PageAddDish.xaml
    /// </summary>
    public partial class PageAddDish : Page
    {
        public PageAddDish()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (DbConnect.entObj.Dish.Count(x => x.Name == TxbFood.Text) > 0)
            {
                MessageBox.Show("Такое блюдо уже есть!",
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }
            else
            {
                if (TxbFood.Text == null | TxbFood.Text.Trim() == "" | TypeAdd.Text == null | TypeAdd.Text.Trim() == "" | TxbOutput.Text == null | TxbOutput.Text.Trim() == "")
                {
                    MessageBox.Show("Заполните все поля!",
                        "Уведомление",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
                else
                {
                    try
                    {

                        Dish dishObj = new Dish()
                        {
                            Name = TxbFood.Text,
                            Output = Convert.ToInt32(TxbOutput.Text),
                            Type = TypeAdd.Text,
                            Image = ImgDish.Source.ToString(),
                        };

                        DbConnect.entObj.Dish.Add(dishObj);
                        DbConnect.entObj.SaveChanges();

                        MessageBox.Show("Блюдо добавлено!",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка добавления блюда: " + ex.Message.ToString(),
                        "Критический сбой работы приложения",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    }
                }
            }
        }

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files | *.bmp;*.jpg;*.jpeg;*png;*.tif| All files|*.*";
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == true)
            {
                Uri imageUri = new Uri(openFileDialog.FileName);
                ImgDish.Source = new BitmapImage(imageUri);
            }
        }
    }
}
