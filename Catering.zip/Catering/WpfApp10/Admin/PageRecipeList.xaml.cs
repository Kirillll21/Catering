﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;
using MessageBox = System.Windows.Forms.MessageBox;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для PageRecipeList.xaml
    /// </summary>
    public partial class PageRecipeList : Page
    {
        public PageRecipeList()
        {
            InitializeComponent();

            DgrProducts.ItemsSource = DbConnect.entObj.Recipe.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddRecipe());
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productsForRemoving = DgrProducts.SelectedItems.Cast<Recipe>().ToList();

            var cancel = MessageBox.Show("Вы подтверждаете удаление?",
                            "Подтверждение",
                            MessageBoxButtons.OKCancel);
            if (DialogResult.Cancel == cancel)
            {
                FrameApp.frmObj.Navigate(new PageRecipeList());
            }
            else
            {

                try
                {
                    DbConnect.entObj.Recipe.RemoveRange(productsForRemoving);
                    DbConnect.entObj.SaveChanges();
                    MessageBox.Show("Данные удалены");

                    DgrProducts.ItemsSource = DbConnect.entObj.Recipe.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());

                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DbConnect.entObj.ChangeTracker.Entries().ToList().ForEach(x => x.Reload());
                DgrProducts.ItemsSource = DbConnect.entObj.Recipe.ToList();

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
