﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;
using MessageBox = System.Windows.Forms.MessageBox;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для PageDishList.xaml
    /// </summary>
    public partial class PageDishList : Page
    {
        public PageDishList()
        {
            InitializeComponent();

            DgrProducts.ItemsSource = DbConnect.entObj.Dish.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DbConnect.entObj.ChangeTracker.Entries().ToList().ForEach(x => x.Reload());
                DgrProducts.ItemsSource = DbConnect.entObj.Dish.ToList();

            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddDish());
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productsForRemoving = DgrProducts.SelectedItems.Cast<Dish>().ToList();

            var cancel = MessageBox.Show("Вы подтверждаете удаление?",
                            "Подтверждение",
                            MessageBoxButtons.OKCancel);
            if (DialogResult.Cancel == cancel)
            {
                FrameApp.frmObj.Navigate(new PageDishList());
            }
            else
            {

                try
                {
                    DbConnect.entObj.Dish.RemoveRange(productsForRemoving);
                    DbConnect.entObj.SaveChanges();
                    MessageBox.Show("Данные удалены");

                    DgrProducts.ItemsSource = DbConnect.entObj.Dish.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());

                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
