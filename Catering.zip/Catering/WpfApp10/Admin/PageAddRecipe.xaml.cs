﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для PageAddRecipe.xaml
    /// </summary>
    public partial class PageAddRecipe : Page
    {
        public PageAddRecipe()
        {
            InitializeComponent();

            
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (DbConnect.entObj.Recipe.Count(x => x.IdDish == Convert.ToInt32(TxbDish.Text)) > 0)
            {
                MessageBox.Show("Такой рецепт уже есть!",
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }
            else
            {
                try
                {

                    Recipe recipObj = new Recipe()
                    {
                        IdDish = Convert.ToInt32(TxbDish.Text),
                        Time = Convert.ToInt32(TxbTime.Text),
                        Technology = TxbTechnology.Text,

                    };


                    DbConnect.entObj.Recipe.Add(recipObj);
                    DbConnect.entObj.SaveChanges();

                    MessageBox.Show("Рецепт добавлен!",
                        "Уведомление",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка добавления рецепта: " + ex.Message.ToString(),
                    "Критический сбой работы приложения",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                }
            }
        }
    }
}
