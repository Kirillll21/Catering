﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp10.AppServices;

namespace WpfApp10.Admin
{
    /// <summary>
    /// Логика взаимодействия для ProductToDish.xaml
    /// </summary>
    public partial class ProductToDish : Page
    {
        public ProductToDish()
        {
            InitializeComponent();

            CmbDish.SelectedValuePath = "Id";

            CmbDish.DisplayMemberPath = "Name";
            CmbDish.ItemsSource = DbConnect.entObj.Dish.ToList();

            CmbProduct.SelectedValuePath = "Id";
            CmbProduct.DisplayMemberPath = "Name";
            CmbProduct.ItemsSource = DbConnect.entObj.Product.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (DbConnect.entObj.DishProduct.Count(x => x.IdDish == Convert.ToInt32(CmbDish.Text)) > 0)
            {
                MessageBox.Show("Такое уже есть", 
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            else
            {
                if (DbConnect.entObj.DishProduct.Count(c => c.IdProduct == Convert.ToInt32(CmbProduct.Text)) > 0)
                {
                    MessageBox.Show("Такое уже есть",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                }
                else { 
                try
                {
                    DishProduct dishProductObj = new DishProduct()
                    {
                        IdDish = Convert.ToInt32(CmbDish.Text),
                        IdProduct = Convert.ToInt32(CmbProduct),
                        Weight = Convert.ToInt16(TxbWeight.Text),
                    };
                    DbConnect.entObj.DishProduct.Add(dishProductObj);
                    DbConnect.entObj.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Сбой работы приложения!" + ex.Message.ToString(),
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Warning);
                    
                }
                
            }
            }

        }
    }
}
