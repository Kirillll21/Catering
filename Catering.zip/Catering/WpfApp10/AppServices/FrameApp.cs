﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp10.AppServices
{
    class FrameApp
    {
        public static Frame frmObj;

        public static Button BtnCheck1;
        public static Button BtnCheck2;
        public static Button BtnCheck3;
        public static Button BtnCheck4;
        public static Button BtnCheck5;
        public static Button BtnLogin;
        public static Button BtnRegistr;
    }
}
